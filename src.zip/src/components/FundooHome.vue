<template>
  <NavBar />
</template>

<script>
import NavBar from "./NavBar";

export default {
  name: "FundooHome",
  components: {
    NavBar,
  },
};
</script>
<style scoped>
</style>